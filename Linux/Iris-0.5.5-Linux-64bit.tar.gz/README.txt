To start Iris run:
bash Iris.sh
If you have problems starting Iris please write to us at: contact@iristech.co