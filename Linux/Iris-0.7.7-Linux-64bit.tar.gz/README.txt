To start Iris run:
sh Iris.sh

If you have problems starting Iris please write to me at: daniel@iristech.co
