For 64-bit Linux:
sudo dpkg --add-architecture i386
sudo apt-get update
sudo apt-get install libc6:i386 libncurses5:i386 libstdc++6:i386
sudo apt-get dist-upgrade
sudo ldconfig

Then start Iris mini with:
sudo sh iris-mini.sh

For 32-bit Linux:
Double click iris-mini

(If it doesn't start right click and in Permissions tab check Execute check box)

If you don't see the tray icon, but ? image run it with sudo

If you have problems starting Iris please write to me at: daniel@iristech.co