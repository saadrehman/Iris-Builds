#!/bin/sh
if [ `getconf LONG_BIT` = "64" ]
then
    echo "Starting 64-bit Iris mini"
    `dirname $0`/iris-mini-0.2.2_x64 "$@"
else
    echo "Starting 32-bit Iris mini"
    `dirname $0`/iris-mini-0.2.2_x86 "$@"
fi


