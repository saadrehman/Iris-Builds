For 64-bit Linux:
Double click or
exec ./iris-mini-0.2.1_x64

For 32-bit Linux:
Double click or
exec ./iris-mini-0.2.1_x86

If not executable Right click -> Permissions -> Allow this file to run as a program

If the tray icon show with ? mark try running with "sudo"

If you have any errors try to run
sudo apt-get install build-essential
sudo apt-get install libstdc++6
In terminal

If you any problems starting Iris please write to me at: daniel@iristech.co

Daniel Georgiev - Founder of Iris :)
