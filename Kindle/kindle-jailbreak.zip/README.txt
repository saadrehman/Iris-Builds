Kindle 3.2.1 Jailbreak
By Serge A. Levin
=============================

This is a jailbreak for 3.2.1 devices based on unstable one my Yifan Lu.

I think I managed to reduce brute force to zero, so jailbreak should work
after the first try.

Install it as usually:

1) Copy and paste the correct update for your device
	k2 = Kindle 2 US
	k2i = Kindle 2 International
	dx = Kindle DX US
	dxi = Kindle DX International
	dxg = Kindle DX Graphite
	k3g = Kindle 3 Wifi + 3G (US & Canada)
	k3gb = Kindle 3 Wifi + 3G (Elsewhere)
	k3w = Kindle 3 Wifi
2) Go to the Settings page via Menu -> Settings
3) Select "Update Your Kindle"

