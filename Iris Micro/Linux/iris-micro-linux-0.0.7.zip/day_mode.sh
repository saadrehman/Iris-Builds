#!/bin/bash

`dirname $0`/iris-micro.sh 5000 100
$SHELL
