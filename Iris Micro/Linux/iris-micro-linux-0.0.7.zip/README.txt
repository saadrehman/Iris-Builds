Iris micro protects your eyes in under 1MB

For day time settings double click
day_mode

For night time settings double click
night_mode

To remove the changes caused by Iris micro double click
reset

You can also call Iris micro with custom values for example
iris-micro.sh 2000 50
Will set temperature on 2000K and brightness on 50%

For problems and feedback
daniel@iristech.co

Enjoy :)
